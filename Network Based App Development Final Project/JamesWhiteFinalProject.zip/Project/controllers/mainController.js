//const model = require('../models/connection');
exports.home = (req, res) => {
    res.render('index');
};

exports.contact = (req, res) => {
    res.render('contact');
};

exports.about = (req, res) => {
    res.render('about');
};
