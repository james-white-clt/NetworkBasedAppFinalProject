const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const connectionSchema = new Schema({
    topic: {type: String, required: [true, 'topic is required']},
    sport: {type: String, required: [true, 'sport is required']},
    title: {type: String, required: [true, 'title is required']},
    details: {type: String, required: [true, 'details is required'],
                minLength: [10, 'the content should have at least 10 characters']},
    where: {type: String, required: [true, 'where is required']},
    date: {type: String, required: [true, 'date is required']},
    startTime: {type: String, required: [true, 'startTime is required']},
    endTime: {type: String, required: [true, 'endTime is required']},
    image: {type: String, required: [true, 'image is required']},
    author: {type: Schema.Types.ObjectId, ref: 'User', required:[true, 'User is required']}
},
{timestamps: true}
);

module.exports = mongoose.model('Connection', connectionSchema);